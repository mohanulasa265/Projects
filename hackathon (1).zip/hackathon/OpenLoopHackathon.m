% Physical parameter (from modelling / CAD estimate)
Iy = 2.5e-3;   % kg·m^2

% Time span
tspan = [0 2];

% Small initial angular disturbance (linear region)
theta0 = 5*pi/180;   % 5 degrees
omega0 = 0;

x0 = [theta0; omega0];

% Open-loop pitch dynamics (no control input)
f = @(t,x) [
    x(2);
    0/Iy          % tau_theta = 0
];

[t,x] = ode45(f, tspan, x0);

figure;
plot(t, x(:,1)*180/pi, 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Pitch angle (deg)');
title('Open-loop Pitch Response to Initial Disturbance');
grid on;
