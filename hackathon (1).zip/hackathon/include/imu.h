#ifndef IMU_H
#define IMU_H

void imuInit();
void imuCalibrate();
void imuZeroAngles();
void imuUpdate();

/* Attitude */
float getRoll();     // degrees
float getPitch();    // degrees
float getYaw();      // degrees

/* Acceleration */
float getAccelZ();   // m/s^2 (vertical, gravity removed)

#endif
