#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>

const char* DRONE_SSID = "DRONE_AP";
const char* DRONE_PASS = "12345678";
IPAddress droneIP(192,168,4,1);

WiFiUDP udp;
#define UDP_PORT 8888

/* ANALOG PINS */
#define PIN_ROLL     36
#define PIN_PITCH    39
#define PIN_YAW      35
#define PIN_THROTTLE 34

/* BUTTONS */
#define BTN_ARM      13
#define BTN_LED      14     // AUX button for white LED
#define BUZZER_PIN   15

/* THROTTLE RANGE */
#define THROTTLE_MIN     900
#define THROTTLE_CENTER 1100
#define THROTTLE_MAX    3000

/* COMMAND LIMITS */
#define ROLL_PITCH_MAX 30
#define YAW_RATE_MAX   120

bool armedCmd = false;
bool ledCmd   = false;
bool lastArm  = true;
bool lastLed  = true;

/* DEADZONE */
int dz(int v,int d){ return (abs(v)<d)?0:v; }

void setup(){
  Serial.begin(115200);

  pinMode(BTN_ARM, INPUT_PULLUP);
  pinMode(BTN_LED, INPUT_PULLUP);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);   // buzzer OFF

  analogReadResolution(12);

  WiFi.mode(WIFI_STA);
  WiFi.begin(DRONE_SSID, DRONE_PASS);
  while(WiFi.status() != WL_CONNECTED) delay(100);
}

void loop(){

  /* ARM TOGGLE */
  bool a = digitalRead(BTN_ARM);
  if(lastArm && !a) armedCmd = !armedCmd;
  lastArm = a;

  /* LED TOGGLE */
  bool l = digitalRead(BTN_LED);
  if(lastLed && !l) ledCmd = !ledCmd;
  lastLed = l;

  /* JOYSTICKS */
  int rT = analogRead(PIN_THROTTLE);
  int rR = analogRead(PIN_ROLL)  - 2048;
  int rP = analogRead(PIN_PITCH) - 2048;
  int rY = analogRead(PIN_YAW)   - 2048;

  rR = dz(rR,80);
  rP = dz(rP,80);
  rY = dz(rY,80);

  int roll  = -(rR * ROLL_PITCH_MAX) / 2048;
  int pitch = -(rP * ROLL_PITCH_MAX) / 2048;
  int yaw   =  (rY * YAW_RATE_MAX)   / 2048;

  /* THROTTLE */
  int throttle = THROTTLE_CENTER;
  if(armedCmd){
    if(rT > 2048+80)
      throttle = map(rT,2048+80,4095,THROTTLE_CENTER,THROTTLE_MAX);
    else if(rT < 2048-80)
      throttle = map(rT,0,2048-80,THROTTLE_MIN,THROTTLE_CENTER);
  }

  /* PACKET FORMAT (MUST MATCH DRONE):
     armedCmd, throttle, roll, pitch, yaw, ledCmd
  */
  char pkt[64];
  sprintf(pkt,"%d,%d,%d,%d,%d,%d",
          armedCmd, throttle, roll, pitch, yaw, ledCmd);

  udp.beginPacket(droneIP, UDP_PORT);
  udp.print(pkt);
  udp.endPacket();

  delay(10);
}
