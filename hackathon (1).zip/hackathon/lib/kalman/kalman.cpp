#include "kalman.h"

KalmanFilter::KalmanFilter() {
    X = 0;
    V = 0;
    P = 1;
    Q = 0.05f;
    R = 1.0f;
}

void KalmanFilter::init(float q, float r, float p) {
    Q = q;
    R = r;
    P = p;
    X = 0;
    V = 0;
}

float KalmanFilter::update(float measuredAlt, float accelZ, float dt) {
    X += V * dt + 0.5f * accelZ * dt * dt;
    V += accelZ * dt;

    P += Q;

    float K = P / (P + R);
    X += K * (measuredAlt - X);
    P *= (1.0f - K);

    return X;
}
