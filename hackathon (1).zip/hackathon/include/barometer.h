#ifndef BAROMETER_H
#define BAROMETER_H

void baroInit();
void baroUpdate();

/* Returns altitude in meters */
float getBaroAltitude();

/* Optional debug */
float getBaroTemperature();
float getBaroPressure();

#endif
