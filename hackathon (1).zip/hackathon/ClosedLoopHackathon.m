Iy = 2.5e-3;

Kp_vals = linspace(0, 0.2, 300);
zeta = 0.7;   % damping guideline

R = [];

for Kp = Kp_vals
    Kd = 2*zeta*sqrt(Iy*Kp);  % same structure as firmware
    r = roots([Iy Kd Kp]);
    R = [R; r.'];
end

figure;
plot(real(R), imag(R), 'b.', 'MarkerSize', 6); hold on;
xline(0,'r--','LineWidth',1.2);
xlabel('Real Axis');
ylabel('Imaginary Axis');
title('Root Locus of Pitch/Roll Dynamics (Firmware-Consistent)');
grid on;

% Mark actual firmware pole
r_fw = roots([Iy 0.20 0.10]);
plot(real(r_fw), imag(r_fw), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
legend('Root Locus','Stability Boundary','Firmware Poles');
