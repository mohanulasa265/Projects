#ifndef KALMAN_H
#define KALMAN_H

class KalmanFilter {
public:
    KalmanFilter();

    void init(float q, float r, float p);
    float update(float measuredAlt, float accelZ, float dt);

private:
    float Q;   // process noise
    float R;   // measurement noise
    float P;   // estimation error
    float X;   // estimated altitude
    float V;   // estimated vertical velocity
};

#endif
