#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>

#include "motors.h"
#include "imu.h"
#include "barometer.h"
#include "kalman.h"

#define ESC_MIN   1000
#define ESC_IDLE  1100
#define ESC_MAX   2000
#define FAILSAFE_MS 300

#define LED_ARM_1 18
#define LED_ARM_2 19
#define LED_ARM_3 4

WiFiUDP udp;

/* RX */
bool armed=false, motorsArmed=false;
int throttleCmd=ESC_MIN, rollCmd=0, pitchCmd=0, yawCmd=0;
unsigned long lastRx=0;

/* STATIC TRIMS (FINAL VALUES) */
#define YAW_STATIC_BIAS    3    // small, stable
#define ROLL_STATIC_BIAS   8
#define PITCH_STATIC_BIAS  6    // fixes nose-down/up

/* PID */
struct PID { float kp,ki,kd,i,last; };

PID pidRoll  ={0.10f,0.00f,0.01f,0,0};
PID pidPitch ={0.10f,0.00f,0.01f,0,0};
PID pidYaw   ={0.05f,0.00f,0.00f,0,0};
PID pidAlt   ={0.6f ,0.20f,0.00f,0,0};

const float ATT_SCALE = 6.0f;

/* Kalman (ALTITUDE) */
KalmanFilter altKalman;
float targetAlt=0;
bool whiteLedCmd = false;

float pidUpdate(PID &p,float sp,float m,float dt){
  float e=sp-m;
  p.i+=e*dt;
  p.i=constrain(p.i,-40,40);
  float d=(e-p.last)/dt;
  p.last=e;
  return p.kp*e+p.ki*p.i+p.kd*d;
}

void receive(){
  if(!udp.parsePacket()) return;
  char b[64];
  udp.read(b,sizeof(b));

  sscanf(b,"%d,%d,%d,%d,%d,%d",
         &armed,
         &throttleCmd,
         &rollCmd,
         &pitchCmd,
         &yawCmd,
         &whiteLedCmd);

  lastRx = millis();
}



void setup(){
  Serial.begin(115200);

  pinMode(LED_ARM_1, OUTPUT);
  pinMode(LED_ARM_2, OUTPUT);
  pinMode(LED_ARM_3, OUTPUT);

  digitalWrite(LED_ARM_1, LOW);
  digitalWrite(LED_ARM_2, LOW);
  digitalWrite(LED_ARM_3, LOW);


  WiFi.mode(WIFI_AP);
  WiFi.softAP("DRONE_AP","12345678");
  udp.begin(8888);

  motorsInit();
  motorsDisarm();

  imuInit();
  imuCalibrate();
  imuZeroAngles();

  baroInit();
  delay(300);
  baroUpdate();

  altKalman.init(0.05f,1.0f,1.0f);
  targetAlt=getBaroAltitude();
}

void loop(){

  receive();
  if(millis()-lastRx>FAILSAFE_MS) armed=false;

  /* LED CONTROL — NO EARLY RETURN SKIP */
  /* ARM LEDs (19, 4) */
  if(armed){
    digitalWrite(LED_ARM_2, HIGH);
    digitalWrite(LED_ARM_3, HIGH);
  }else{
    digitalWrite(LED_ARM_2, LOW);
    digitalWrite(LED_ARM_3, LOW);
  }

  /* WHITE LED (18) — controlled by button */
  if(armed && whiteLedCmd){
    digitalWrite(LED_ARM_1, HIGH);
  }else{
    digitalWrite(LED_ARM_1, LOW);
  }



  if(!armed){
    motorsDisarm();
    motorsArmed=false;
    return;
  }

  if(!motorsArmed){
    motorsArm();
    motorsArmed=true;
    pidAlt.i=0;
    baroUpdate();
    targetAlt=getBaroAltitude();
    return;
  }

  static unsigned long lm=micros();
  float dt=(micros()-lm)*1e-6f; lm=micros();
  if(dt<0.002f) dt=0.002f;

  imuUpdate();
  baroUpdate();

  float roll=getRoll();
  float pitch=getPitch();
  float yawRate=getYaw();
  float accelZ=getAccelZ();

  float kalAlt = altKalman.update(getBaroAltitude(),accelZ,dt);

  /* PID */
  float rollPID  = pidUpdate(pidRoll , rollCmd , roll , dt);
  float pitchPID = pidUpdate(pidPitch, pitchCmd, pitch, dt);
  float yawPID   = pidUpdate(pidYaw  , yawCmd  , yawRate, dt);

  rollPID  *= ATT_SCALE;
  pitchPID *= ATT_SCALE;
  yawPID   *= ATT_SCALE;

  rollPID  = constrain(rollPID ,-25,25);
  pitchPID = constrain(pitchPID,-25,25);
  yawPID   = constrain(yawPID  ,-30,30);

  /* Altitude hold only when sticks neutral */
  float altPID=0;
  if(abs(rollCmd)<2 && abs(pitchCmd)<2){
    altPID=pidUpdate(pidAlt,targetAlt,kalAlt,dt);
    altPID=constrain(altPID,-60,60);
  }

  int throttle = constrain(throttleCmd+altPID,ESC_IDLE,ESC_MAX);

  motorsWrite(
    throttle + pitchPID + rollPID - YAW_STATIC_BIAS - ROLL_STATIC_BIAS - PITCH_STATIC_BIAS - yawPID,
    throttle - pitchPID + rollPID + YAW_STATIC_BIAS - ROLL_STATIC_BIAS + PITCH_STATIC_BIAS + yawPID,
    throttle - pitchPID - rollPID - YAW_STATIC_BIAS + ROLL_STATIC_BIAS + PITCH_STATIC_BIAS - yawPID,
    throttle + pitchPID - rollPID + YAW_STATIC_BIAS + ROLL_STATIC_BIAS - PITCH_STATIC_BIAS + yawPID
  );

  delay(4);
}
