#include "imu.h"
#include <Wire.h>
#include <math.h>

/* ========== IMU REGISTERS (LSM6DS3) ========== */
#define IMU_ADDR 0x6A

#define CTRL1_XL 0x10
#define CTRL2_G  0x11

#define OUTX_L_G  0x22
#define OUTX_L_XL 0x28

/* ========== SCALE FACTORS ========== */
#define GYRO_SCALE  0.035f   // deg/s per LSB (±1000 dps)
#define ACC_SCALE   0.000061f // g per LSB (±2g)
#define G_TO_MS2    9.80665f



// === IMU AXIS ALIGNMENT ===
// Adjust these until behavior is correct
// +1 or -1 only
#define IMU_ROLL_SIGN   +1
#define IMU_PITCH_SIGN  +1
#define IMU_YAW_SIGN    +1


/* ========== INTERNAL STATE ========== */
static float roll = 0, pitch = 0, yaw = 0;
static float accZ_ms2 = 0;

static float gyroBiasZ = 0;
static unsigned long lastMicros;

/* ========== LOW LEVEL I2C ========== */
static int16_t read16(uint8_t reg) {
    Wire.beginTransmission(IMU_ADDR);
    Wire.write(reg);
    Wire.endTransmission(false);
    Wire.requestFrom(IMU_ADDR, (uint8_t)2);
    return Wire.read() | (Wire.read() << 8);
}

static void write8(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(IMU_ADDR);
    Wire.write(reg);
    Wire.write(val);
    Wire.endTransmission();
}

/* ========== INIT ========== */
void imuInit() {
    Wire.begin();

    write8(CTRL1_XL, 0x60); // Accel: 416 Hz, ±2g
    write8(CTRL2_G,  0x68); // Gyro: 416 Hz, ±1000 dps

    lastMicros = micros();
}

/* ========== CALIBRATION ========== */
void imuCalibrate() {
    long sumZ = 0;

    for (int i = 0; i < 2000; i++) {
        sumZ += read16(OUTX_L_G + 4);
        delay(2);
    }

    gyroBiasZ = (sumZ / 2000.0f) * GYRO_SCALE;
}

void imuZeroAngles() {
    roll = pitch = yaw = 0;
}

/* ========== UPDATE LOOP ========== */
void imuUpdate() {

    unsigned long now = micros();
    float dt = (now - lastMicros) * 1e-6f;
    lastMicros = now;

    /* --- GYRO --- */
    float gx = read16(OUTX_L_G)     * GYRO_SCALE;
    float gy = read16(OUTX_L_G + 2) * GYRO_SCALE;
    float gz = read16(OUTX_L_G + 4) * GYRO_SCALE - gyroBiasZ;

    /* --- ACCEL --- */
    float ax = read16(OUTX_L_XL)     * ACC_SCALE;
    float ay = read16(OUTX_L_XL + 2) * ACC_SCALE;
    float az = read16(OUTX_L_XL + 4) * ACC_SCALE;

    /* --- ACC ANGLES --- */
    float rollAcc  = atan2(ay, az) * 57.2958f;
    float pitchAcc = atan2(-ax, sqrt(ay * ay + az * az)) * 57.2958f;

    /* --- COMPLEMENTARY FILTER --- */
    roll  = 0.98f * (roll  + gx * dt) + 0.02f * rollAcc;
    pitch = 0.98f * (pitch + gy * dt) + 0.02f * pitchAcc;
    yaw  += gz * dt;

    /* --- VERTICAL ACC (remove gravity) --- */
    accZ_ms2 = (az - 1.0f) * G_TO_MS2;
}

/* ========== GETTERS ========== */
float getRoll()  { return IMU_ROLL_SIGN  * roll; }
float getPitch() { return IMU_PITCH_SIGN * (-pitch); }
float getYaw()   { return IMU_YAW_SIGN   * yaw; }

float getAccelZ() { return accZ_ms2; }
