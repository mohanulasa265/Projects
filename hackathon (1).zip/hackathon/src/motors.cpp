#include <Arduino.h>
#include <ESP32Servo.h>
#include "motors.h"

/* -------- MOTOR SIGNAL PINS -------- */
#define M1_PIN 12   // Front Left
#define M2_PIN 13   // Rear Left
#define M3_PIN 14   // Rear Right
#define M4_PIN 15   // Front Right


/* -------- ESC SIGNAL RANGE -------- */
#define ESC_MIN   1000
#define ESC_IDLE  1100
#define ESC_MAX   2000

static Servo motor1, motor2, motor3, motor4;
static bool armed = false;

void motorsInit() {
    motor1.attach(M1_PIN, ESC_MIN, ESC_MAX);
    motor2.attach(M2_PIN, ESC_MIN, ESC_MAX);
    motor3.attach(M3_PIN, ESC_MIN, ESC_MAX);
    motor4.attach(M4_PIN, ESC_MIN, ESC_MAX);

    motorsDisarm();
}

void motorsArm() {
    armed = true;

    motor1.writeMicroseconds(ESC_IDLE);
    motor2.writeMicroseconds(ESC_IDLE);
    motor3.writeMicroseconds(ESC_IDLE);
    motor4.writeMicroseconds(ESC_IDLE);
}

void motorsDisarm() {
    armed = false;

    motor1.writeMicroseconds(ESC_MIN);
    motor2.writeMicroseconds(ESC_MIN);
    motor3.writeMicroseconds(ESC_MIN);
    motor4.writeMicroseconds(ESC_MIN);
}

void motorsWrite(int m1, int m2, int m3, int m4) {
    if (!armed) return;

    m1 = constrain(m1, ESC_MIN, ESC_MAX);
    m2 = constrain(m2, ESC_MIN, ESC_MAX);
    m3 = constrain(m3, ESC_MIN, ESC_MAX);
    m4 = constrain(m4, ESC_MIN, ESC_MAX);

    motor1.writeMicroseconds(m1);
    motor2.writeMicroseconds(m2);
    motor3.writeMicroseconds(m3);
    motor4.writeMicroseconds(m4);
}

bool motorsAreArmed() {
    return armed;
}
