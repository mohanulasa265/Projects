#ifndef MOTORS_H
#define MOTORS_H

// Initialize ESCs and motors
void motorsInit();

// Arm motors (idle speed)
void motorsArm();

// Disarm motors (safe)
void motorsDisarm();

// Write motor outputs (microseconds)
void motorsWrite(int m1, int m2, int m3, int m4);

// Check armed state
bool motorsAreArmed();

#endif
