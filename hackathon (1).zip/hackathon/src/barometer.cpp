#include "barometer.h"
#include <Wire.h>
#include <math.h>

/* ================= BMP280 ================= */
#define BMP280_ADDR 0x76

#define BMP280_CHIP_ID   0xD0
#define BMP280_RESET     0xE0
#define BMP280_CTRL_MEAS 0xF4
#define BMP280_CONFIG    0xF5

/* ================= CALIBRATION ================= */
static uint16_t dig_T1;
static int16_t  dig_T2, dig_T3;
static uint16_t dig_P1;
static int16_t  dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;

static int32_t t_fine;

static float temperature = 0.0f;
static float pressurePa  = 0.0f;
static float altitudeM   = 0.0f;

/* ================= I2C ================= */
static void write8(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(BMP280_ADDR);
    Wire.write(reg);
    Wire.write(val);
    Wire.endTransmission();
}

static uint8_t read8(uint8_t reg) {
    Wire.beginTransmission(BMP280_ADDR);
    Wire.write(reg);
    Wire.endTransmission();
    Wire.requestFrom(BMP280_ADDR, 1);
    return Wire.read();
}

static uint16_t read16(uint8_t reg) {
    Wire.beginTransmission(BMP280_ADDR);
    Wire.write(reg);
    Wire.endTransmission();
    Wire.requestFrom(BMP280_ADDR, 2);
    uint16_t v = Wire.read();
    v |= Wire.read() << 8;
    return v;
}

static int16_t readS16(uint8_t reg) {
    return (int16_t)read16(reg);
}

/* ================= CALIBRATION READ ================= */
static void readCalibration() {
    dig_T1 = read16(0x88);
    dig_T2 = readS16(0x8A);
    dig_T3 = readS16(0x8C);

    dig_P1 = read16(0x8E);
    dig_P2 = readS16(0x90);
    dig_P3 = readS16(0x92);
    dig_P4 = readS16(0x94);
    dig_P5 = readS16(0x96);
    dig_P6 = readS16(0x98);
    dig_P7 = readS16(0x9A);
    dig_P8 = readS16(0x9C);
    dig_P9 = readS16(0x9E);
}

/* ================= INIT ================= */
void baroInit() {
    Wire.begin(21, 22);   // ESP32 I2C pins

    uint8_t id = read8(BMP280_CHIP_ID);
    if (id != 0x58) {
        while (1); // BMP280 not found → hard stop
    }

    write8(BMP280_RESET, 0xB6);
    delay(100);

    readCalibration();

    /* Normal mode, temp + pressure oversampling x1 */
    write8(BMP280_CTRL_MEAS, 0x27);
    write8(BMP280_CONFIG, 0x00);
}

/* ================= UPDATE ================= */
void baroUpdate() {

    /* ---------- TEMPERATURE ---------- */
    int32_t adc_T;
    Wire.beginTransmission(BMP280_ADDR);
    Wire.write(0xFA);
    Wire.endTransmission();
    Wire.requestFrom(BMP280_ADDR, 3);

    adc_T = (Wire.read() << 12) | (Wire.read() << 4) | (Wire.read() >> 4);

    int32_t var1 = ((((adc_T >> 3) - ((int32_t)dig_T1 << 1))) * dig_T2) >> 11;
    int32_t var2 = (((((adc_T >> 4) - (int32_t)dig_T1) *
                      ((adc_T >> 4) - (int32_t)dig_T1)) >> 12) *
                    dig_T3) >> 14;

    t_fine = var1 + var2;
    temperature = (t_fine * 5 + 128) / 25600.0f;

    /* ---------- PRESSURE ---------- */
    int32_t adc_P;
    Wire.beginTransmission(BMP280_ADDR);
    Wire.write(0xF7);
    Wire.endTransmission();
    Wire.requestFrom(BMP280_ADDR, 3);

    adc_P = (Wire.read() << 12) | (Wire.read() << 4) | (Wire.read() >> 4);

    int64_t v1 = (int64_t)t_fine - 128000;
    int64_t v2 = v1 * v1 * dig_P6;
    v2 += ((v1 * dig_P5) << 17);
    v2 += ((int64_t)dig_P4 << 35);
    v1 = ((v1 * v1 * dig_P3) >> 8) + ((v1 * dig_P2) << 12);
    v1 = (((((int64_t)1) << 47) + v1) * dig_P1) >> 33;

    if (v1 == 0) return;

    int64_t p = 1048576 - adc_P;
    p = (((p << 31) - v2) * 3125) / v1;
    v1 = ((int64_t)dig_P9 * (p >> 13) * (p >> 13)) >> 25;
    v2 = ((int64_t)dig_P8 * p) >> 19;
    p = ((p + v1 + v2) >> 8) + ((int64_t)dig_P7 << 4);

    pressurePa = p / 256.0f;

    /* ---------- ALTITUDE ---------- */
    altitudeM = 44330.0f * (1.0f - pow(pressurePa / 101325.0f, 0.1903f));
}

/* ================= GETTERS ================= */
float getBaroAltitude()   { return altitudeM; }
float getBaroTemperature(){ return temperature; }
float getBaroPressure()  { return pressurePa; }
